# 02 BitLocker Compliance

## 🎯 Goal
Describe the purpose of this project and what problem it solves.

## 🔧 Steps
1. Step one
2. Step two
3. Step three

## 📷 Evidence
Screenshots and logs go here.

## ✅ Result
Summarize what was achieved.

## 🧠 Reflection
What did you learn? What would you improve?
