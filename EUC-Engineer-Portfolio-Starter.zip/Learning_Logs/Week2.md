# Week 2 Learning Log

## 📅 Dates
[Start Date] - [End Date]

## 🎯 Goal
What you aimed to learn this week.

## 🔧 Activities
- Task 1
- Task 2

## 📷 Evidence
(Screenshots, script snippets)

## 🧠 Reflection
- What went well?
- What challenges did you face?
- What’s next?
